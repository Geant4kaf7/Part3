#include <PrimaryPart.hh>

PrimaryPart::PrimaryPart(std::ofstream& ofsa)
{
 GProton = new G4ParticleGun(1);
 GProton->SetParticleDefinition(G4Proton::ProtonDefinition());
 GProton->SetParticleEnergy(1000. * MeV);

 this->f_prim=&ofsa;
 (*f_prim) << std::setw(12) << "Hi from PrimaryPart!" << std::endl;
}

PrimaryPart::~PrimaryPart() 
{
 (*f_prim) << std::setw(12) << "Bye from PrimaryPart!" << std::endl;
}

//��������� ���������
void PrimaryPart::GeneratePrimaries(G4Event* anEvent) 
{
 GProton->SetParticlePosition(G4ThreeVector(0*mm , 0*mm, -5.*cm));
 GProton->SetParticleMomentumDirection(G4ThreeVector(0, 0, 1));
 GProton->GeneratePrimaryVertex(anEvent); 
}
