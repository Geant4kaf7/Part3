#include <PrimaryPart.hh>

PrimaryPart::PrimaryPart(std::ofstream& ofsa)
{
 this->f_prim=&ofsa;
 (*f_prim) << std::setw(12) << "Hi from PrimaryPart!" << G4endl;
 commandMessenger = new CommandMessenger(this);
 GProton = new G4ParticleGun(1);
 GProton->SetParticleDefinition(G4Proton::ProtonDefinition());
 GProton->SetParticleEnergy(100. * MeV);
// GNeutron = new G4ParticleGun(1);
// GNeutron->SetParticleDefinition(G4Neutron::NeutronDefinition()); 
}

PrimaryPart::~PrimaryPart() 
{
 (*f_prim) << std::setw(12) << "Bye from PrimaryPart!" << G4endl;
 delete commandMessenger;
}

//��������� ���������
void PrimaryPart::GeneratePrimaries(G4Event* anEvent) 
{
 GProton->SetParticlePosition(G4ThreeVector(0*mm , 0*mm, -21.*cm));
 GProton->SetParticleMomentumDirection(G4ThreeVector(0, 0, 1));
 GProton->GeneratePrimaryVertex(anEvent); 
}
