//#ifndef M_DGW_4_STEPACTION_HH
//#define M_DGW_4_STEPACTION_HH

#include <G4UserSteppingAction.hh>
#include <G4Step.hh>

class StepAct :public G4UserSteppingAction {
public:
        std::ofstream *f_step;

        StepAct(std::ofstream& ofsa)
        {
         this->f_step=&ofsa;
         (*f_step) << "Hi from Step!" << std::endl;
        };
        ~StepAct()
        {
         (*f_step) << "Bye from Step!" << std::endl;
        };	

	void UserSteppingAction(const G4Step*);
};

//#endif
